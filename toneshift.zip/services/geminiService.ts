import { GoogleGenAI, Type } from "@google/genai";
import { Tone } from "../types";

const apiKey = process.env.API_KEY;

if (!apiKey) {
  console.error("API_KEY is not set in the environment variables.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || 'dummy-key-for-build' });

export const rewriteText = async (text: string, tone: Tone): Promise<string[]> => {
  try {
    let promptInstruction = "";
    
    if (tone === Tone.GRAMMAR) {
      promptInstruction = `Fix the grammar and spelling of the following text. Do not change the tone or style. Keep the length strictly similar to the original. Provide 3 distinct variations.`;
    } else {
      promptInstruction = `Rewrite the following sentence in a ${tone} tone. IMPORTANT: Keep the sentence length approximately the same as the original. Do not make it significantly longer or add unnecessary elaboration. Keep it natural. Provide 3 distinct variations.`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `${promptInstruction}
      
      Original Text: "${text}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING
          },
          description: "A list of 3 rewritten sentence variations."
        },
        systemInstruction: "You are an expert editor. Your goal is to rewrite text to match a specific tone or fix grammar while strictly preserving the original length and meaning.",
      }
    });

    const jsonText = response.text;
    if (!jsonText) {
      throw new Error("Empty response from AI");
    }

    const variations = JSON.parse(jsonText) as string[];
    return variations;

  } catch (error) {
    console.error("Error generating variations:", error);
    throw error;
  }
};