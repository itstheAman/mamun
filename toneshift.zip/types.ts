export enum Tone {
  GRAMMAR = 'Grammar',
  PROFESSIONAL = 'Professional',
  CASUAL = 'Casual',
  POLITE = 'Polite',
  FUNNY = 'Funny',
  CONFIDENT = 'Confident',
  ROMANTIC = 'Romantic',
  SARCASTIC = 'Sarcastic'
}

export interface RewriteResult {
  variations: string[];
}

export interface UsageData {
  date: string;
  count: number;
}

export interface ToneOption {
  id: Tone;
  label: string;
  emoji: string;
}