import React, { useRef, useEffect } from 'react';
import { Tone } from '../types';
import { TONE_OPTIONS } from '../constants';

interface ToneSelectorProps {
  selectedTone: Tone;
  onSelectTone: (tone: Tone) => void;
  disabled?: boolean;
}

const ToneSelector: React.FC<ToneSelectorProps> = ({ selectedTone, onSelectTone, disabled }) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Optional: Auto scroll to selected item if needed, but for now simple manual scroll is fine
  
  return (
    <div className="w-full mb-6">
      <h3 className="text-sm font-medium text-secondary mb-3 px-1">Select Tone</h3>
      <div 
        ref={scrollContainerRef}
        className="flex overflow-x-auto gap-3 pb-2 no-scrollbar snap-x"
        style={{ scrollBehavior: 'smooth' }}
      >
        {TONE_OPTIONS.map((option) => {
          const isSelected = selectedTone === option.id;
          return (
            <button
              key={option.id}
              onClick={() => onSelectTone(option.id)}
              disabled={disabled}
              className={`
                snap-start flex-shrink-0 px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-200 border
                ${isSelected 
                  ? 'bg-primary text-white border-primary shadow-lg shadow-gray-200 scale-105' 
                  : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }
                ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
              `}
            >
              <span className="mr-2">{option.emoji}</span>
              {option.label}
            </button>
          );
        })}
        {/* Spacer for right padding in scroll view */}
        <div className="w-2 flex-shrink-0" />
      </div>
    </div>
  );
};

export default ToneSelector;