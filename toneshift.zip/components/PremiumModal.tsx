import React from 'react';
import { X, Sparkles, CheckCircle2 } from 'lucide-react';

interface PremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgrade: () => void;
}

const PremiumModal: React.FC<PremiumModalProps> = ({ isOpen, onClose, onUpgrade }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity" 
        onClick={onClose}
      />
      <div className="relative bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl transform transition-all animate-fade-in">
        
        {/* Header Image / Gradient */}
        <div className="h-32 bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-1 bg-white/20 hover:bg-white/30 rounded-full text-white transition-colors"
          >
            <X size={20} />
          </button>
          <Sparkles size={48} className="text-white opacity-90" />
        </div>

        <div className="p-8">
          <h2 className="text-2xl font-bold text-center text-gray-900 mb-2">Unlock Unlimited</h2>
          <p className="text-center text-gray-500 mb-8">
            You've reached your daily limit of free rewrites. Upgrade to ToneShift Pro for unlimited access.
          </p>

          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-3 text-gray-700">
              <CheckCircle2 size={20} className="text-green-500 flex-shrink-0" />
              <span>Unlimited rewrites per day</span>
            </div>
            <div className="flex items-center gap-3 text-gray-700">
              <CheckCircle2 size={20} className="text-green-500 flex-shrink-0" />
              <span>Access to exclusive tones</span>
            </div>
            <div className="flex items-center gap-3 text-gray-700">
              <CheckCircle2 size={20} className="text-green-500 flex-shrink-0" />
              <span>Faster generation speed</span>
            </div>
          </div>

          <button
            onClick={onUpgrade}
            className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold py-4 rounded-xl shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all duration-200"
          >
            Upgrade for $4.99/mo
          </button>
          
          <button 
            onClick={onClose}
            className="w-full mt-4 text-sm text-gray-400 hover:text-gray-600 font-medium"
          >
            Maybe later
          </button>
        </div>
      </div>
    </div>
  );
};

export default PremiumModal;