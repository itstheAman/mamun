import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

interface ResultCardProps {
  text: string;
  index: number;
}

const ResultCard: React.FC<ResultCardProps> = ({ text, index }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <div 
      className="group bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-300 animate-slide-up relative"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <p className="text-gray-800 text-lg leading-relaxed pr-8 font-light">
        {text}
      </p>
      
      <button
        onClick={handleCopy}
        className="absolute top-4 right-4 p-2 rounded-full text-gray-400 hover:bg-gray-50 hover:text-gray-600 transition-colors"
        aria-label="Copy text"
      >
        {copied ? (
          <Check size={18} className="text-green-500" />
        ) : (
          <Copy size={18} />
        )}
      </button>
    </div>
  );
};

export default ResultCard;