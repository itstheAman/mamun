import { useState, useEffect } from 'react';
import { DAILY_LIMIT } from '../constants';
import { UsageData } from '../types';

export const useUsageLimit = () => {
  const [remaining, setRemaining] = useState<number>(DAILY_LIMIT);
  const [isPremium, setIsPremium] = useState<boolean>(false);

  useEffect(() => {
    // Check local storage on mount
    const storedPremium = localStorage.getItem('toneShift_premium');
    if (storedPremium === 'true') {
      setIsPremium(true);
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    const storedUsage = localStorage.getItem('toneShift_usage');

    if (storedUsage) {
      const data: UsageData = JSON.parse(storedUsage);
      if (data.date === today) {
        setRemaining(Math.max(0, DAILY_LIMIT - data.count));
      } else {
        // New day, reset
        localStorage.setItem('toneShift_usage', JSON.stringify({ date: today, count: 0 }));
        setRemaining(DAILY_LIMIT);
      }
    } else {
      // First time
      localStorage.setItem('toneShift_usage', JSON.stringify({ date: today, count: 0 }));
      setRemaining(DAILY_LIMIT);
    }
  }, []);

  const decrementUsage = () => {
    if (isPremium) return;

    const today = new Date().toISOString().split('T')[0];
    const storedUsage = localStorage.getItem('toneShift_usage');
    let currentCount = 0;

    if (storedUsage) {
      const data: UsageData = JSON.parse(storedUsage);
      if (data.date === today) {
        currentCount = data.count;
      }
    }

    const newCount = currentCount + 1;
    localStorage.setItem('toneShift_usage', JSON.stringify({ date: today, count: newCount }));
    setRemaining(Math.max(0, DAILY_LIMIT - newCount));
  };

  const upgradeToPremium = () => {
    setIsPremium(true);
    localStorage.setItem('toneShift_premium', 'true');
  };

  return { remaining, isPremium, decrementUsage, upgradeToPremium };
};