import { Tone, ToneOption } from './types';

export const TONE_OPTIONS: ToneOption[] = [
  { id: Tone.GRAMMAR, label: 'Fix Grammar', emoji: '✨' },
  { id: Tone.PROFESSIONAL, label: 'Professional', emoji: '💼' },
  { id: Tone.CASUAL, label: 'Casual', emoji: '👕' },
  { id: Tone.POLITE, label: 'Polite', emoji: '🍵' },
  { id: Tone.FUNNY, label: 'Funny', emoji: '😂' },
  { id: Tone.CONFIDENT, label: 'Confident', emoji: '🦁' },
  { id: Tone.ROMANTIC, label: 'Romantic', emoji: '🌹' },
  { id: Tone.SARCASTIC, label: 'Sarcastic', emoji: '🙄' },
];

export const DAILY_LIMIT = 5;

export const SAMPLE_PROMPTS = [
  "I'm not coming to work today because I'm sick.",
  "That idea is terrible.",
  "I love you so much.",
  "Can you help me with this task?",
  "The meeting was too long and boring."
];