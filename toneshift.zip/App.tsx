import React, { useState, useEffect } from 'react';
import { Sparkles, Wand2, Menu, Crown, AlertCircle } from 'lucide-react';
import { Tone } from './types';
import { rewriteText } from './services/geminiService';
import ToneSelector from './components/ToneSelector';
import ResultCard from './components/ResultCard';
import PremiumModal from './components/PremiumModal';
import { useUsageLimit } from './hooks/useUsageLimit';
import { SAMPLE_PROMPTS } from './constants';

const App: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [selectedTone, setSelectedTone] = useState<Tone>(Tone.PROFESSIONAL);
  const [results, setResults] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showPremium, setShowPremium] = useState(false);

  const { remaining, isPremium, decrementUsage, upgradeToPremium } = useUsageLimit();

  const handleRewrite = async (toneOverride?: Tone) => {
    const activeTone = toneOverride || selectedTone;

    if (!inputText.trim()) {
      setError("Please enter some text first.");
      return;
    }

    if (!isPremium && remaining <= 0) {
      setShowPremium(true);
      return;
    }

    setIsLoading(true);
    setError(null);
    setResults([]);

    try {
      const variations = await rewriteText(inputText, activeTone);
      setResults(variations);
      decrementUsage();
    } catch (err) {
      setError("Something went wrong. Please check your connection and try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSampleClick = (text: string) => {
    setInputText(text);
    setError(null);
  };

  return (
    <div className="min-h-full flex flex-col items-center py-6 px-4 sm:px-6 lg:px-8 max-w-lg mx-auto w-full relative">
      
      {/* Top Bar */}
      <div className="w-full flex justify-between items-center mb-8">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-lg shadow-gray-200">
            <Wand2 className="text-white" size={20} />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-primary">ToneShift</h1>
        </div>
        
        <button 
          onClick={() => setShowPremium(true)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
            isPremium 
              ? 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white shadow-md' 
              : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
          }`}
        >
          <Crown size={14} fill={isPremium ? "currentColor" : "none"} />
          {isPremium ? "PRO" : `${remaining} left`}
        </button>
      </div>

      {/* Input Section */}
      <div className="w-full mb-6">
        <div className="relative">
          <textarea
            value={inputText}
            onChange={(e) => {
              setInputText(e.target.value);
              if (error) setError(null);
            }}
            placeholder="Type or paste a sentence here..."
            className="w-full min-h-[140px] p-5 rounded-3xl bg-white border-2 border-transparent focus:border-gray-200 focus:bg-white focus:outline-none focus:ring-0 resize-none text-lg text-gray-800 placeholder-gray-300 shadow-sm transition-all duration-300"
            style={{ boxShadow: '0 4px 20px rgba(0,0,0,0.03)' }}
          />
          {inputText && (
            <button 
              onClick={() => setInputText('')}
              className="absolute top-4 right-4 text-gray-300 hover:text-gray-500 text-xs font-medium bg-gray-50 px-2 py-1 rounded-md"
            >
              CLEAR
            </button>
          )}
        </div>
        
        {/* Sample Prompts (Only show if empty) */}
        {!inputText && !results.length && (
          <div className="mt-4 overflow-x-auto no-scrollbar pb-2">
            <div className="flex gap-2">
              {SAMPLE_PROMPTS.slice(0, 3).map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSampleClick(prompt)}
                  className="flex-shrink-0 px-4 py-2 bg-white rounded-xl border border-gray-100 text-xs text-gray-500 hover:border-gray-200 hover:text-gray-700 transition-all whitespace-nowrap shadow-sm"
                >
                  {prompt.length > 25 ? prompt.substring(0, 25) + '...' : prompt}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Tone Selection */}
      <ToneSelector 
        selectedTone={selectedTone} 
        onSelectTone={(tone) => {
          setSelectedTone(tone);
          if (inputText.trim()) {
            handleRewrite(tone);
          }
        }}
        disabled={isLoading} 
      />

      {/* Action Button */}
      <button
        onClick={() => handleRewrite()}
        disabled={isLoading || !inputText.trim()}
        className="w-full bg-primary text-white font-semibold py-4 rounded-2xl shadow-xl shadow-gray-200 hover:shadow-2xl hover:scale-[1.01] active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none transition-all duration-300 flex items-center justify-center gap-2 mb-8"
      >
        {isLoading ? (
          <>
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            <span>Rewriting...</span>
          </>
        ) : (
          <>
            <Sparkles size={18} />
            <span>Rewrite Text</span>
          </>
        )}
      </button>

      {/* Error Message */}
      {error && (
        <div className="w-full p-4 mb-6 bg-red-50 text-red-600 rounded-2xl flex items-center gap-3 animate-fade-in">
          <AlertCircle size={20} />
          <p className="text-sm font-medium">{error}</p>
        </div>
      )}

      {/* Results Section */}
      <div className="w-full space-y-4 pb-12">
        {results.map((result, index) => (
          <ResultCard key={index} text={result} index={index} />
        ))}
      </div>

      {/* Premium Modal */}
      <PremiumModal 
        isOpen={showPremium} 
        onClose={() => setShowPremium(false)}
        onUpgrade={() => {
          upgradeToPremium();
          setShowPremium(false);
        }}
      />
    </div>
  );
};

export default App;